chrome.runtime.onMessage.addListener((
    function(e,t,i){
        if("Sending Data"==e.msg){
            let t=e.keys;
            
            setTimeout((
                function(){
                    document.querySelector(`#page-wrapper > p-student > app-learning-test > div.adaptive-question > div > div > div.adaptive-question-box.bg-white.p-1.ng-star-inserted > div:nth-child(2) > mcq-question > div > div.question-answers.mb-0 > div:nth-child(${t+1}) > div > label > input`).click();
                }
            ) ,500)
        }
        "start"==e.msg&&chrome.runtime.sendMessage({msg:"startPanel"})
    }
));

//# sourceMappingURL=contentScript.js.map