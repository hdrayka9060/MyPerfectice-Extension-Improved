chrome.devtools.panels.create("TUTORIEX",null,"panel.html",null);
//# sourceMappingURL=devtool.js.map